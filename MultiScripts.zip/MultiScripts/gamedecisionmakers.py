from gameobjects import *
from gameactions import *
import torch
import torch.nn as nn
import torch.nn.functional as F

class RecurrentPolicy(nn.Module):
    def __init__(self, input_dim, hidden_dim, action_dim):
        super().__init__()

        self.fc_in = nn.Linear(input_dim, hidden_dim)
        self.lstm = nn.LSTM(hidden_dim, hidden_dim, batch_first=True)
        self.fc_out = nn.Linear(hidden_dim, action_dim)

    def forward(self, obs, hidden, action_mask):
        """
        obs: (batch, seq_len, input_dim)
        hidden: (h, c) or None
        action_mask: (batch, action_dim)
        """

        x = F.relu(self.fc_in(obs))        # (batch, seq_len, hidden)
        x, hidden = self.lstm(x, hidden)  # x: (batch, seq_len, hidden)

        last_output = x[:, -1]            # use last timestep
        logits = self.fc_out(last_output) # (batch, action_dim)

        # mask illegal actions with -inf
        logits = logits.masked_fill(action_mask == 0, float('-inf'))

        probs = F.softmax(logits, dim=-1)
        return probs, hidden
def onehotmoves(moves):
        #function takes in a list of move instances and gives a onehot encoding of each
        movenames=[move.movename for move in moves]#contains the NAMES of moves rather than instances ex:"Wizard1" 
        movelist=encodemoves(movenames)#one-hot encoded list of possible moves

        return movelist
def convertanswer(possible_moves, action_index):
    # lookup name of the global move at this index
    movename = allmoves[action_index]

    # find the move instance in the legal list
    for move in possible_moves:
        if move.movename == movename:
            return move

    # fallback (should never happen)
    return possible_moves[0]
    

# -----------------------------
# DecisionMaker (random for now)
# -----------------------------
class DecisionMaker():
    def __init__(self):
        pass
    def reset(self):
        pass
class DumbDecisionMaker(DecisionMaker):
    def __init__(self,name="Dummy"):
       
        self.name=name
    def choose_move(self,possible_moves,information):
        return np.random.choice(possible_moves)
        
class NeuralDecisionMaker(DecisionMaker):
    def __init__(self, policy=None,state_dim=infolength, hidden_dim=128, action_dim=len(allmoves), name="BigBrain"):
            
        if policy is None:
                
            self.policy = RecurrentPolicy(input_dim=state_dim,
                                         hidden_dim=hidden_dim,
                                         action_dim=action_dim)
        else:
            self.policy=policy
                
        self.name = name
        self.trajectory = []
        self.hidden = None  # LSTM hidden state
    def reset(self):
        self.hidden = None    # call this at episode start

    def choose_move(self, possible_moves, information):
        # information is your flat 87-dim state
        state = torch.tensor(information, dtype=torch.float32).unsqueeze(0).unsqueeze(0)
        # shape = (1, 1, 87)

        action_mask = torch.tensor(onehotmoves(possible_moves), dtype=torch.float32).unsqueeze(0)
        # shape = (1, 37)

        # forward LSTM
        probs, self.hidden = self.policy(state, self.hidden, action_mask)

        dist = torch.distributions.Categorical(probs)
        action = dist.sample()

        # save log-prob for REINFORCE
        self.trajectory.append({
            "log_prob": dist.log_prob(action),
        })

        return convertanswer(possible_moves, action.item())
def reinforce_update(policy, optimizer, trajectory, reward,health1,mana1,mana2):
    if len(trajectory) == 0:
        return
    
    
    
    
    reward_tensor = torch.tensor(reward, dtype=torch.float32)
    loss = torch.stack([-step["log_prob"] * reward_tensor for step in trajectory]).sum()

    optimizer.zero_grad()
    loss.backward()
    optimizer.step()

    trajectory.clear()
# -----------------------------
# Example simulation
# -----------------------------
class simulator():
    def __init__(self,player1, player2, length=20, prnt=True, offset=[0,0],show=False):
        self.player1=player1
        self.player2=player2
        self.length=length
        self.prnt=prnt
        self.offset=offset
        self.show=show
    def simulate(self):
      
        game = Game(self.player1, self.player2, self.length, self.prnt, self.offset,self.show)
        reward=game.play()
        
        
        returndict={"reward":reward,
                   "health1":game.player_1.base_health,
                   "mana1":game.player_1.mana,
                   "health2":game.player_2.base_health,
                   "mana2":game.player_2.mana}
        return returndict
import numpy as np
from collections import Counter
defaultlimits={
    WizardCard:2,
    GhostCard:4,
    ManaTowerCard:4,
    HealCard:4,
    ExecutionerCard:3,
    NukeCard:2,
    ExorcismCard:3,
    ThornCard:3

}
def make_deck(team=0, size=20, cards=None, prnt=True, limits=defaultlimits):

    l = []

    if not cards:
        cards = [ThornCard,WizardCard, GhostCard, HealCard, ExorcismCard, ExecutionerCard,ManaTowerCard,NukeCard]

    # Default: no limits (infinite)
    for card in cards:
        if card not in limits:
    
            limits[card] = float('inf')

    # Keep count of how many of each card we've added
    counts = {c: 0 for c in cards}

    while len(l) < size:
        # Choose from cards that haven't hit their limit yet
        available = [c for c in cards if counts[c] < limits[c]]
        if not available:
            raise ValueError("No more cards available — all limits reached before deck filled.")

        card_cls = np.random.choice(available)
        l.append(card_cls(team=team))
        counts[card_cls] += 1

    if prnt:
        print_deck(l)
    return l


def print_deck(deck=None):
    if not deck:
        deck=make_deck()

    print(Counter([item.name for item in deck]))
