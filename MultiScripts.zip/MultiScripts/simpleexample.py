from gameactions import *
from gameobjects import *
from gamedecisionmakers import *
newlimits={
    WizardCard:2,
    GhostCard:2,
    ManaTowerCard:4,
    HealCard:2,
    ExecutionerCard:2,
    NukeCard:1,
    ExorcismCard:2
    
    
}
for a in range(10):
    deck1=make_deck(0,limits=newlimits)
    deck2=make_deck(1,limits=newlimits)
    p1 = GamePlayer(difficulty=1,game=None,deck=deck1, decision_maker=DumbDecisionMaker(), length=len(allmoves))
    p2 = GamePlayer(difficulty=1,game=None,deck=deck2, decision_maker=DumbDecisionMaker(), length=len(allmoves))
    sim = simulator(p1, p2, length=50, prnt=True,show=True)
    simresult = sim.simulate()