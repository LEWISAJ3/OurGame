import pygame



snap1 = {
           
            "My_Mana": int(5),
            "Their_Mana": int(3),
            "My_Health": int(10),
            "Their_Health": int(11),
            
            "Their_Currently_Visible_Cards": ["Wizard0"],
            "Their_cardhealths":["5",0,0,0],
            "My_cardhealths":[2,0,0,0],
            "My_Active_Cards":["Ghost0"],
            "Their_Deck":["Ghost"],
            "My_Deck":["Wizard","Executioner"],
            "Action Taken":["Fireball0"]
            
        }
snap2 = {
           
            "My_Mana": int(3),
            "Their_Mana": int(3),
            "My_Health": int(10),
            "Their_Health": int(11),
            
            "Their_Currently_Visible_Cards": ["Wizard0"],
            "Their_cardhealths":["5",0,0,0],
            "My_cardhealths":[2,0,0,6],
            "My_Active_Cards":["Ghost0","Wizard3"],
            "Their_Deck":["Ghost"],
            "My_Deck":["Executioner"],
            "Action Taken":["Fireball0"]
            
        }
def make_board_image(snapshot=snap1,w=600, h=500):
    pygame.init()
    # Create a surface instead of a display window
    
    surface = pygame.Surface((w, h))
    redmana=snapshot["Their_Mana"]
    redhealth=snapshot["Their_Health"]
    redstuff=snapshot["Their_Currently_Visible_Cards"]
    redhealths=snapshot["Their_cardhealths"]
    reddeck=snapshot["Their_Deck"]
    bluemana=snapshot["My_Mana"]
    bluehealth=snapshot["My_Health"]
    bluestuff=snapshot["My_Active_Cards"]
    bluehealths=snapshot["My_cardhealths"]
    bluedeck=snapshot["My_Deck"]
    # ---------- Convert items to sprite filenames ----------
    
    def convert(stuff, modifier,length=4):
        converter = {
            "Wizard": f"{modifier}wizard.png",
            "Ghost": f"{modifier}ghost.png",
            "Executioner": f"{modifier}executioner.png",
            "ManaTower": f"{modifier}manatower.png",
            "ThornSpell": f"{modifier}thorn.png",
            "NukeSpell": f"{modifier}nuke.png",
            "ExorcismSpell": f"{modifier}exorcism.png",
            "HealSpell": f"{modifier}heal.png"
        }
        newstuff = ["nothing.png"]*length
        
        for index,item in enumerate(stuff):
            for key in converter:
                if key in str(item):
                    
                    newstuff[index]=converter[key]
                    break
                
        return newstuff
    def deckconvert(stuff, modifier,length=5):
        converter = {
            "Wizard": f"{modifier}wizard.png",
            "Ghost": f"{modifier}ghost.png",
            "Executioner": f"{modifier}executioner.png",
            "ManaTower": f"{modifier}manatower.png",
            "ThornSpell": f"{modifier}thorn.png",
            "NukeSpell": f"{modifier}nuke.png",
            "ExorcismSpell": f"{modifier}exorcism.png",
            "HealSpell": f"{modifier}heal.png"
        }
        newstuff = ["nothing.png"]*length
        
        for index,item in enumerate(stuff):
            for key in converter:
                if key in str(item):
                    
                    newstuff[index]=converter[key]
                    break
                
        return newstuff
    reddecks=deckconvert(reddeck,"red")
    bluedecks=deckconvert(bluedeck,"blue")
    redfiles = deckconvert(redstuff, "red",4)
    bluefiles = deckconvert(bluestuff, "blue",4)
    
    # ---------- Build sprite dictionaries ----------
    reddeckitems={}
    reditems = {}
    blueitems = {}
    bluedeckitems={}

    for i, file in enumerate(reddecks):
        img = pygame.transform.scale(pygame.image.load(file), (w//5, h//10))
        reddeckitems[i] = {"object": img,
                       "position": (i*w//5, 12*h//100)}

    for i, file in enumerate(bluedecks):
        img = pygame.transform.scale(pygame.image.load(file), (w//5, h//10))
        bluedeckitems[i] = {"object": img,
                        "position": (i*w//5, 8*h//10)}
    for i, file in enumerate(redfiles):
        img = pygame.transform.scale(pygame.image.load(file), (w//4, h//10))
        reditems[i] = {"object": img,
                       "position": (i*w//4, 26*h//100),
                       "name": str(redhealths[i])}

    for i, file in enumerate(bluefiles):
        img = pygame.transform.scale(pygame.image.load(file), (w//4, h//10))
        blueitems[i] = {"object": img,
                        "position": (i*w//4, 65*h//100),
                        "name": str(bluehealths[i])}

    # ---------- Draw onto surface ----------
    surface.fill((0, 0, 0))
    font = pygame.font.SysFont(None, 32)
    txt = font.render(f"Their Health: {redhealth} Their Mana: {redmana}", True, (255, 255, 255))
    rect = txt.get_rect(center=(w//2, h//20))
    surface.blit(txt, rect)
    txt2 = font.render(f"Their Deck", True, (255, 255, 255))
    rect2 = txt2.get_rect(center=(w//2, h//10))
    surface.blit(txt2, rect2)
    txt3 = font.render(f"Their Active Cards", True, (255, 255, 255))
    rect3 = txt3.get_rect(center=(w//2, 12*h//50))
    surface.blit(txt3, rect3)
    txt4 = font.render(f"          Your Active Cards", True, (255, 255, 255))
    rect4 = txt.get_rect(center=(w//2, h*57//100))
    surface.blit(txt4, rect4)
    txt4 = font.render(f"My Deck", True, (255, 255, 255))
    rect4 = txt4.get_rect(center=(w//2, 78*h//100))
    surface.blit(txt4, rect4)
    txt5 = font.render(f"Their Active Cards", True, (255, 255, 255))
    rect5 = txt5.get_rect(center=(w//2, 12*h//50))
    surface.blit(txt5, rect5)
    txt6 = font.render(f"My Health: {bluehealth} Their Mana: {bluemana}", True, (255, 255, 255))
    rect6 = txt6.get_rect(center=(w//2, h*15//16))
    surface.blit(txt6, rect6)
    # red units
    for item in reditems.values():
        obj, pos = item["object"], item["position"]
        surface.blit(obj, pos)
        txt = font.render(item["name"], True, (255, 255, 255))
        rect = txt.get_rect(center=(pos[0] + obj.get_width()/2, pos[1] + 2*h//16))
        surface.blit(txt, rect)

    # blue units
    for item in blueitems.values():
        obj, pos = item["object"], item["position"]
        surface.blit(obj, pos)
        txt = font.render(item["name"], True, (255, 255, 255))
        rect = txt.get_rect(center=(pos[0] + obj.get_width()/2, pos[1] +-1*h//32))
        surface.blit(txt, rect)
    for item in reddeckitems.values():
        obj, pos = item["object"], item["position"]
        surface.blit(obj, pos)
        

    # blue units
    for item in bluedeckitems.values():
        obj, pos = item["object"], item["position"]
        surface.blit(obj, pos)
        

    return surface







def make_animation(surfs):
    pygame.init()
    for index,surf in enumerate(surfs):
        pygame.image.save(surf, f"screenshots/board{index}.png")

    import tkinter as tk
    from PIL import Image, ImageTk

    root = tk.Tk()
    canvas = tk.Canvas(root, width=600, height=500)
    canvas.pack()

    images = [ImageTk.PhotoImage(file=f"screenshots/board{i}.png") for i in range(len(surfs))]
    current = 0
    image_on_canvas = canvas.create_image(300, 250, image=images[current])

    def next_image(event):
        nonlocal current
        if event.keysym == "Right":
            current = (current + 1) % len(images)
        elif event.keysym == "Left":
            current = (current - 1) % len(images)
        canvas.itemconfig(image_on_canvas, image=images[current])

    root.bind("<Key>", next_image)
    root.mainloop()
reds = [{"stuff":["Wizard0", "0", "Executioner3", "Ghost2"],
"healths": [10, 0, 2, 8]},
{"stuff":["Wizard2", "0", "Executioner3", "Ghost1"],
"healths": [10, 4, 2, 6]}]


blues = [{"stuff":["Wizard0", "0", "Executioner3", "Ghost2"],
"healths" : [10, 0, 4, 9]},{"stuff":["Wizard1", "0", "Executioner3", "Ghost0"],
"healths" : [10, 4, 2, 9]}]

#surfs=[make_board_image(snap1),make_board_image(snap2)]
#make_animation(surfs)

