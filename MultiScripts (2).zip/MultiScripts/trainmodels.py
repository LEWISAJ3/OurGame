from gameactions import *
from gameobjects import *
from gamedecisionmakers import *
import time
import copy
import torch
import torch.nn as nn
import torch.nn.functional as F
from collections import Counter
def train_models(num_models,num_episodes):
    resultholder={}

    ddm = DumbDecisionMaker()
    toplayagainst = [ddm]
    totaltime = 0

    for newmodel in range(num_models):
        
        

        # create new policy + DM
        
        
        
        
        dm_new = NeuralDecisionMaker(name=f"Model{newmodel+1}")
        optimizer = torch.optim.Adam(dm_new.policy.parameters(), lr=.001)
        
        
            


        # pick opponent
        
        
        print(f"\n=== TRAINING MODEL #{dm_new.name}")
        start=time.time()
        maxepisodes=num_episodes*(1+newmodel)
        for episode in range(maxepisodes):
            dm_opponent = np.random.choice(toplayagainst)
            



            # fresh decks
            deck1 = make_deck(0, size=20, prnt=False)#
            deck2 = make_deck(1, size=20, prnt=False)
            #deck1=[GhostCard(team=0)]*8 +[ExorcismCard(team=0)]*1 + [NukeCard(team=0)]*6
            #deck2=[GhostCard(team=1)]*8 +[ExorcismCard(team=1)]*1 + [NukeCard(team=1)]*6
            # CLONE the opponent DM (important!)
            # build fresh agent using the policy of dm_opponent
            if isinstance(dm_opponent, NeuralDecisionMaker):


                dm2 = NeuralDecisionMaker(policy=copy.deepcopy(dm_opponent.policy), name=dm_opponent.name)
                
                

            else:
                dm2 = DumbDecisionMaker()

            # reset only the NEW one
            dm_new.reset()
            dm2.reset()
            if f"{dm_new.name}" not in resultholder.keys():
                resultholder[f"{dm_new.name}"]={}
            if f"{dm2.name}" not in resultholder[f"{dm_new.name}"].keys():
                resultholder[f"{dm_new.name}"][f"{dm2.name}"]=[]

            # assign players
            if episode % 2 == 0:
                p1 = GamePlayer(difficulty=1,game=None,deck=deck1, decision_maker=dm_new, length=len(allmoves))
                p2 = GamePlayer(difficulty=1,game=None,deck=deck2, decision_maker=dm2, length=len(allmoves))
                sim = simulator(p1, p2, length=50, prnt=False,show=False)
                simresult = sim.simulate()
                reward=simresult["reward"]
                health=simresult["health1"]
                mana1=simresult["mana1"]
                mana2=simresult["mana2"]
            else:
                p1 = GamePlayer(difficulty=1,game=None,deck=deck2, decision_maker=dm2, length=len(allmoves))
                p2 = GamePlayer(difficulty=1,game=None,deck=deck1, decision_maker=dm_new, length=len(allmoves))
                sim = simulator(p1, p2, length=50, prnt=False,show=False)
                simresult = sim.simulate()
                reward=-simresult["reward"]
                health=simresult["health2"]
                mana1=simresult["mana2"]
                mana2=simresult["mana1"]
            # update only new model
            reinforce_update(dm_new.policy, optimizer, dm_new.trajectory, reward,health,mana1,mana2)

            
            if (episode%50==0 and episode>0):
                elapsed = time.time() - start
                totaltime += elapsed
                print(f"Episodes {episode-50} to {episode} took {elapsed:.2f}s, total {totaltime:.2f}s")
                start = time.time()
            if episode==maxepisodes-1:
                elapsed = time.time() - start
                totaltime += elapsed
                print(f"Final training took {elapsed:.2f}s, total {totaltime:.2f}s")
                start = time.time()
                

            resultholder[f"{dm_new.name}"][f"{dm2.name}"].append(reward)
        toplayagainst.append(dm_new)
    returndict={"resultholder":resultholder,
                    "models":toplayagainst}
    return returndict




        
