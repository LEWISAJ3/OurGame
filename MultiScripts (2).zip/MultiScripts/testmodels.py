import matplotlib.pyplot as plt
import numpy as np
from gameactions import *
from gameobjects import *
from gamedecisionmakers import *

from trainmodels import train_models
from collections import Counter
# results is a list of 1=Win, 0=Draw, -1=Loss
results=train_models(num_models=3,num_episodes=80)
resultholder=results["resultholder"]
toplayagainst=results["models"]

import time
import copy
testresultholder={}


totaltime = 0





# create new policy + DM










 # pick opponent



start=time.time()
maxepisodes=1000
for episode in range(maxepisodes):
    dm1,dm2 = np.random.choice(toplayagainst,2,replace=False)




    # fresh decks
    deck1 = make_deck(0, size=20, prnt=False)#
    deck2 = make_deck(1, size=20, prnt=False)
    #deck1=[GhostCard(team=0)]*8 +[ExorcismCard(team=0)]*1 + [NukeCard(team=0)]*6
    #deck2=[GhostCard(team=1)]*8 +[ExorcismCard(team=1)]*1 + [NukeCard(team=1)]*6
    # CLONE the opponent DM (important!)
    # build fresh agent using the policy of dm_opponent
    if isinstance(dm1, NeuralDecisionMaker):


        dm1 = NeuralDecisionMaker(policy=copy.deepcopy(dm1.policy), name=dm1.name)



    else:
        dm1 = DumbDecisionMaker()
    if isinstance(dm2, NeuralDecisionMaker):


        dm2 = NeuralDecisionMaker(policy=copy.deepcopy(dm2.policy), name=dm1.name)



    else:
        dm2 = DumbDecisionMaker()

    # reset only the NEW one
    dm1.reset()
    dm2.reset()
    if f"{dm1.name}" not in testresultholder.keys():
        testresultholder[f"{dm1.name}"]={}
    if f"{dm2.name}" not in testresultholder[f"{dm1.name}"].keys():
        testresultholder[f"{dm1.name}"][f"{dm2.name}"]=[]

    # assign players
    if episode % 2 == 0:
        p1 = GamePlayer(difficulty=1,game=None,deck=deck1, decision_maker=dm1, length=len(allmoves))
        p2 = GamePlayer(difficulty=1,game=None,deck=deck2, decision_maker=dm2, length=len(allmoves))
        sim = simulator(p1, p2, length=50, prnt=False,show=False)
        simresult = sim.simulate()
        reward=simresult["reward"]
        
    else:
        p1 = GamePlayer(difficulty=1,game=None,deck=deck2, decision_maker=dm2, length=len(allmoves))
        p2 = GamePlayer(difficulty=1,game=None,deck=deck1, decision_maker=dm1, length=len(allmoves))
        sim = simulator(p1, p2, length=50, prnt=False,show=False)
        simresult = sim.simulate()
        reward=-simresult["reward"]
        
    # update only new model
   


    if (episode%50==0 and episode>0):
        elapsed = time.time() - start
        totaltime += elapsed
        print(f"Episodes {episode-50} to {episode} took {elapsed:.2f}s, total {totaltime:.2f}s")
        start = time.time()
    if episode==maxepisodes-1:
        elapsed = time.time() - start
        totaltime += elapsed
        print(f"Final training took {elapsed:.2f}s, total {totaltime:.2f}s")
        start = time.time()


    testresultholder[f"{dm1.name}"][f"{dm2.name}"].append(reward)
testwinrates={}
for key1 in testresultholder.keys():
    
    num_ones=0
    ln=0
    for key2 in testresultholder[key1].keys():
        num_ones+=Counter(testresultholder[key1][key2])[1]
        ln+=len(testresultholder[key1][key2])
    testwinrates[key1]=num_ones/ln
sorted_list = np.array(sorted(testwinrates.items(), key=lambda x: x[1]))
sorted_list[:,1]=[float(x) for x in sorted_list[:,1]]
import re
import pandas as pd
def model_to_number(name):
    if name.lower() == "dummy":
        return 0
    match = re.search(r'\d+', name)
    return int(match.group()) if match else 0
sorted_list[:,0]=[model_to_number(x) for x in sorted_list[:,0]]
sorted_list=sorted_list.astype("float")
df=pd.DataFrame(sorted_list,columns=["Model Number","Winrate"])
print(df)
plt.scatter(sorted_list[:,0],sorted_list[:,1])
plt.ylim(0,1)
plt.plot((-1,11),(.5,.5))
plt.xlim(0,10)