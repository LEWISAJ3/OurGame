class Effect:
    def __init__(self, owner, source=None):
        self.owner = owner      # usually the player
        self.source = source    # the troop or item that caused this effect
        self.active = True

    def tick(self, effects):
        pass


class ManaTowerEffect(Effect):
    def tick(self,player):
        if player.game.prnt:
            print(f"{self.source.name} grants +1 mana.")
        self.owner.mana += 1
class HiddenThornmailEffect(Effect):
    def tick(self,card,caster,damage):
        caster.take_damage(card,damage,reflected=True)
        if card.prnt:
            print(f"Damage reduced from {damage} to {damage-2}")
        damage=max(0,damage-2)
        card.damage=damage
            
        
        if self in card.defeffects:
            card.defeffects.remove(self)
        self.active=False
        self.owner.largedeck.appendleft(ThornCard(card.team))
        
        
        



# -----------------------------
# Card base class
# -----------------------------
class Card():
    def __init__(self, type_="", team=0, mana_cost=0, name="", hidden=False):
        self.type = type_
        self.team = team
        self.mana_cost = mana_cost
        self.name = name
        self.hidden = hidden
        self.deployed = False
        self.dead = False
        self.square = None
        self.exhausted=False
        self.health=0
        self.initial_health=0
        self.defeffects=[]
        self.player=None
        self.game=None
        self.prnt=False
    def get_possible_moves(self, game):
        pass
    def gain_player(self,player):
        self.player=player
        self.game=player.game
        self.prnt=self.game.prnt
    def die(self,player):
        """Troop dies and returns to largedeck for reuse."""
        if player is None:
            return
        self.deployed = False
        if self in player.active_cards:
            player.active_cards.remove(self)
        if self.square:
            self.square.troop=None
            self.square.empty=True
        if self in player.deck:
            player.deck.remove(self)
        player.largedeck.appendleft(self)  # Recycle the card
        self.square = None
        self.health=self.initial_health
    def take_damage(self,caster,damage ,reflected=False):
        if self.square is None or not self.deployed:
            return
        self.damage=damage
        if not reflected:
            for effect in self.defeffects.copy():
                
                effect.tick(self,caster,self.damage)
        self.health-=self.damage
        if self.prnt:
            print(f"Player{self.team+1}'s {self.name} on Square {self.square.index} took {self.damage} damage! {self.health} remaining. ")
        if self.health<=0:
            self.die(self.player)
            if self.prnt:
                print("It died!")
# -----------------------------
# WizardCard
# -----------------------------
class WizardCard(Card):
    def __init__(self, team=0):
        super().__init__(type_="troop", team=team, mana_cost=6,name="Wizard")
        self.initial_health=8
        self.health = 8
        self.hidden=False
        self.exhausted=False
        self.ability_cost=6

    def get_possible_moves(self, game,player):
        
        moves = []
        if not self.deployed and player.mana>=self.mana_cost:
            for sq in player.available_squares:
                if sq.empty:
                    moves.append(DeployTroopMove(self, sq,player))
        else:
            opponent = game.players[1 - player.team]
            if player.mana >= self.ability_cost and not self.exhausted and self.deployed:
                for sq in opponent.available_squares:
                    moves.append(FireballMove(self, sq,player))
        return moves
class ThornCard(Card):
    def __init__(self, team=0):
        super().__init__(type_="spell", team=team, mana_cost=4,name="ThornSpell")
        self.initial_health=100
        self.health = 100
        self.hidden=False
        self.exhausted=False
        self.ability_cost=100
    def get_possible_moves(self, game,player):
        
        moves = []
        if player.mana>=self.mana_cost:
            for sq in player.available_squares:
                if not sq.empty:
                    
                    if not any(type(x) is HiddenThornmailEffect for x in sq.troop.defeffects):
                        
                        moves.append(ThornMove(self, sq,player))
                        
        return moves

# -----------------------------
# WizardCard
# -----------------------------
class GhostCard(Card):
    def __init__(self, team=0):
        super().__init__(type_="troop", team=team, mana_cost=4, name="Ghost")
        self.health = 4
        self.initial_health=4
        self.hidden=True
        self.exhausted=False
        self.ability_cost=2
        self.damage=1
        
    def get_possible_moves(self, game,player):
        self.player = player
        moves = []
        if not self.deployed and player.mana>=self.mana_cost:
            for sq in player.available_squares:
                if sq.empty:
                    moves.append(DeployTroopMove(self, sq,player))
        else:
            opponent = game.players[1 - player.team]
            if player.mana >= self.ability_cost and not self.exhausted and self.deployed:
                for sq in opponent.available_squares:
                    moves.append(HauntMove(self,sq,self.damage,self.ability_cost,player))

        return moves
    def die(self,player):
        self.ability_cost=2
        self.damage=1
        super().die(player)
        
        

class HealCard(Card):
    def __init__(self, team=0):
        super().__init__(type_="spell", team=team, mana_cost=3, name="HealSpell")
        self.health = 1000
        self.hidden=True
        self.exhausted=False
        self.ability_cost=1000
    def get_possible_moves(self, game, player):
        self.player = player
        

        opponent = game.players[1 - player.team]
        if player.mana >= self.mana_cost and not self.exhausted:
             

            return [HealMove(self,player)]
        return []
class ExorcismCard(Card):
    def __init__(self, team=0):
        super().__init__(type_="spell", team=team, mana_cost=4, name="ExorcismSpell")
        self.health = 1000
        self.hidden=True
        self.exhausted=False
        
    def get_possible_moves(self, game, player):
        self.player = player
        

        opponent = game.players[1 - player.team]
        if player.mana >= self.mana_cost and not self.exhausted:
             

            return [ExorcismMove(self,player)]
        return []

class NukeCard(Card):
    def __init__(self, team=0):
        super().__init__(type_="spell", team=team, mana_cost=12, name="NukeSpell")
        self.health = 1000
        self.hidden=True
        self.exhausted=False
        self.ability_cost=1000
    def get_possible_moves(self, game, player):
        self.player = player
        

        opponent = game.players[1 - player.team]
        if player.mana >= self.mana_cost and not self.exhausted:
             

            return [NukeMove(self,player)]
        return []
# -----------------------------
# ExecutionerCard
# -----------------------------
class ExecutionerCard(Card):
    def __init__(self, team=0):
        super().__init__(type_="troop", team=team, mana_cost=4,name="Executioner")
        self.initial_health=8
        self.health = 8
        self.hidden=False
        self.exhausted=False
        self.ability_cost=2
        self.execution_threshold=60

    def get_possible_moves(self, game, player):
        self.player = player
        moves = []
        if not self.deployed and player.mana>=self.mana_cost:
            for sq in player.available_squares:
                if sq.empty:
                    moves.append(DeployTroopMove(self, sq,player))
        else:
            opponent = game.players[1 - player.team]
            if player.mana >= self.ability_cost and not self.exhausted and self.deployed:
                for sq in [square for square in opponent.available_squares if not square.empty and not square.troop.hidden]:
                    if sq.troop.health<=.01*self.execution_threshold*sq.troop.initial_health:
                        moves.append(ExecutionerMove(self, sq,player))
        return moves

# -----------------------------
# ExecutionerCard
# -----------------------------
class ManaTowerCard(Card):
    def __init__(self,team=0):
        super().__init__(type_="troop",team=team,mana_cost=4,name="ManaTower")
        self.initial_health=7
        self.health=self.initial_health
        self.hidden=False
        self.exhausted=False
        self.ability_cost=6
        self.effect=None
        self.deployed=False
    def get_possible_moves(self, game, player):
        self.player = player
        moves = []
        if not self.deployed and player.mana>=self.mana_cost:
            for sq in player.available_squares:
                if sq.empty:
                    moves.append(DeployManaTowerMove(self, sq,player))
        return moves
    def die(self,player):
         
        super().die(player)
        if self.effect in player.passive_effectors:
            player.passive_effectors.remove(self.effect)
# -----------------------------
# Square and BuffSquare
# -----------------------------
class Square:
    def __init__(self, index, troop=Card()):
        self.index = index
        self.troop = troop
        self.empty = True

class BuffSquare:
    def __init__(self):
        self.empty = True
# -----------------------------
# Move base class
# -----------------------------
class Move():
    
    def execute(self, game):
        pass

# -----------------------------
# DeployTroopMove
# -----------------------------
class DeployTroopMove(Move):
    def __init__(self, card, square,player):
        self.card = card
        self.square = square
        self.mana_cost = card.mana_cost
        self.player=player
        self.type="Deploy"
        self.movename=card.name+str(square.index)
    def execute(self, game):
        player=self.player
        if self.player.mana < self.mana_cost:
            if game.prnt:
                print(f"❌ Not enough mana to deploy {self.card.name}!")
                print(f" Mana needed: {self.mana_cost} Current Mana: {player.mana}")
            return
        player.mana -= self.mana_cost
        self.square.troop = self.card
        self.square.empty = False
        self.card.deployed = True
        self.card.square = self.square
        if self.card in player.deck:
            player.deck.remove(self.card)
        player.active_cards.append(self.card)
        player.move_played=(self.card.name,self.square.index)
        if game.prnt:
            print(f"🧙 {self.card.name} deployed on square {self.square.index}. Mana: {player.mana}")
class DeployManaTowerMove(Move):
    def __init__(self, card, square,player):
        self.card = card
        self.square = square
        self.card.effect=ManaTowerEffect(player,card)
        self.player=player
        self.mana_cost=self.card.mana_cost
        self.type="Deploy"
        self.movename=card.name+str(square.index)
    def execute(self, game):
        player=self.player
        if self.player.mana < self.mana_cost:
            if game.prnt:
                print(f"❌ Not enough mana to deploy {self.card.name}!")
                print(f" Mana needed: {self.mana_cost} Current Mana: {player.mana}")
            return
        player.mana -= self.mana_cost
        self.square.troop = self.card
        self.square.empty = False
        self.card.deployed = True
        self.card.square = self.square
        if self.card in player.deck:
            player.deck.remove(self.card)
        player.active_cards.append(self.card)
        if game.prnt:
            print(f"🧙 {self.card.name} deployed on square {self.square.index}. Mana: {player.mana}")
        self.player.passive_effectors.append(self.card.effect)
class ThornMove(Move):
    def __init__(self, card, square,player):
        self.card = card
        self.square = square
        self.card.effect=HiddenThornmailEffect(player,card)
        self.player=player
        self.mana_cost=self.card.mana_cost
        self.type="Spell"
        self.movename=card.name+str(square.index)
    def execute(self,game):
        if self.card.effect in self.square.troop.defeffects:
            return
        self.square.troop.defeffects.append(self.card.effect)
        self.player.deck.remove(self.card)
        self.player.mana-=self.mana_cost
        if self.player.game.prnt:
            print(f"Thorn spell casted on player{self.player.team+1}'s {self.square.troop.name} on square {self.square.index}")
        
        

class FireballMove(Move):
    def __init__(self, caster, target_square,player):
        self.caster = caster
        self.target_square = target_square
        self.mana_cost = caster.ability_cost
        self.player=player
        self.type="DamageAbility"
        self.name="Fireball"
        self.movename=self.name+str(target_square.index)
    def execute(self, game):
        player=self.player
        if player.mana < self.mana_cost and not self.caster.exhausted:
            if game.prnt:
                print("❌ Not enough mana for fireball!")
                print(f" Mana needed: {self.mana_cost} Current Mana: {player.mana}")
            return
        player.mana -= self.mana_cost
        opponent = game.players[1 - player.team]
        squares = opponent.available_squares
        idx = squares.index(self.target_square)
        self.caster.exhausted=True

        if game.prnt:
            print(f"Player{player.team+1}'s Wizard on square {self.caster.square.index} casts Fireball at enemy square {idx}! Mana left: {player.mana}")

        splash_indices = [i for i in [idx-1, idx, idx+1] if 0 <= i < len(squares)]
        splash_damage = 6 / len(splash_indices)
        overkill = 0

        for i in splash_indices:
            sq = squares[i]
            if not sq.empty and sq.troop and hasattr(sq.troop, "health") and not sq.troop.dead:
                sq.troop.take_damage(self.caster,splash_damage)
                
                    
                if hasattr(sq.troop, "health"): 
                    if sq.troop.health <= 0:
                        overkill += -sq.troop.health
                        
                        sq.troop.die(opponent)
                        sq.troop = None
                        sq.empty = True
            else:
                overkill += splash_damage  # hitting empty square counts as overkill

        if overkill > 0:
            opponent.base_health -=overkill
            if game.prnt:
                print(f"🏰 {overkill:.1f} overkill damage to opponent base! Remaining: {opponent.base_health:.1f}")

        if opponent.base_health <= 0:
            if game.prnt:
                print("🎉 Opponent base destroyed! Game over.")
            game.game_over = True
class HauntMove(Move):
    def __init__(self, caster, target_square,damage,mana_cost,player):
        self.caster = caster
        self.target_square = target_square
        self.mana_cost = mana_cost
        self.damage=damage
        self.player=player
        self.type="DamageAbility"
        self.name="Haunt"
        self.movename=self.name+str(target_square.index)
    def execute(self, game):
        player=self.player
        if player.mana < self.mana_cost and not self.caster.exhausted:
            if game.prnt:
                
                print("❌ Not enough mana for haunt!")
                print(f" Mana needed: {self.mana_cost} Current Mana: {player.mana}")
            return
        player.mana -= self.mana_cost
        opponent = game.players[1 - player.team]
        squares = opponent.available_squares
        idx = squares.index(self.target_square)
        self.caster.exhausted=True

        if game.prnt:
            print(f"Player{player.team+1}'s Ghost on square {self.caster.square.index} casts Haunt at enemy square {idx}! Mana left: {player.mana}")

        
        if not self.target_square.empty:
            self.target_square.troop.take_damage(self.caster,self.damage)
            
            
                
        
            
            
        

        
        if game.prnt:
            print(f" {self.damage} damage to opponent base! Remaining: {opponent.base_health:.1f}")    
        self.caster.damage+=1
        self.caster.ability_cost+=2
        opponent.base_health-=self.damage
        

        if opponent.base_health <= 0:
            if game.prnt:
                print("🎉 Opponent base destroyed! Game over.")
            game.game_over = True
class HealMove(Move):
    def __init__(self,card,player):
        self.card=card
        self.player=player
        self.mana_cost = card.mana_cost
        self.type="NoTargetSpell"
        self.movename=card.name
    def execute(self, game):
        self.player.mana-=self.mana_cost
        if game.prnt:
            print(f"Player {self.player.team+1} casts heal!")
        if self.player.active_cards:
            for card in self.player.active_cards:
                card.health = card.health+2
                if game.prnt and card.square:
                    print(f"Player {self.player.team+1}'s {card.name} on square {card.square.index} is now {card.health} hp!")
        else:
            self.player.base_health+=1
            if game.prnt:
                print(f"Player {self.player.team+1}'s base is healed! Remaining Health:{self.player.base_health} hp!")
            
                  
                
        
            
        self.card.die(self.player)
class ExorcismMove(Move):
    def __init__(self,card,player):
        self.card=card
        self.player=player
        self.mana_cost = card.mana_cost
        self.type="NoTargetSpell"
        self.movename=card.name
    def execute(self, game):
        opponent=game.players[1-self.player.team]
        self.player.mana-=self.mana_cost
        if game.prnt:
            print(f"Player {self.player.team+1} casts Exorcism!")
        if opponent.active_cards:
            for square in opponent.available_squares:
                if not square.empty:
                    if square.troop.name=="Ghost":
                        if game.prnt :
                            print(f"Player {opponent.team+1}'s {square.troop.name} on square {square.index} has been Exorcised!")

                        square.troop.die(opponent)
        elif game.prnt:
            print(f"No ghosts deployed!")
           
            
                  
                
        
            
        self.card.die(self.player)
class NukeMove(Move):
    def __init__(self,card,player):
        self.card=card
        self.player=player
        self.mana_cost = card.mana_cost
        self.type="NoTargetSpell"
        self.movename=card.name
    def execute(self, game):
        opponent=game.players[1-self.player.team]
        self.player.mana-=self.mana_cost
        if game.prnt:
            print(f"Player {self.player.team+1} casts Nuke!")
        if opponent.active_cards:
            for square in opponent.available_squares:
                if not square.empty:
                    
                    if game.prnt :
                        print(f"Player {opponent.team+1}'s {square.troop.name} on square {square.index} got cooked.")
                    square.troop.die(opponent)
        opponent.base_health-=2
        if game.prnt :
            print(f"Player {opponent.team+1}'s base got blasted!{opponent.base_health} hp remaining.")
        self.card.die(self.player)
       
# -----------------------------
# EndTurnMove
# -----------------------------
class EndTurnMove(Move):
    def __init__(self, player):
        self.player = player
        self.type="EndTurn"
        self.movename="EndTurn"

    def execute(self, game):
        # End the current player's turn first
        game.change_turn()
        game.moves_played += 1

        # Refresh the new player's deck and info
        new_player = game.players[game.turn]
        old_player = game.players[1 - game.turn]

        old_player.mana += 2
        old_player.refresh_deck()

        
        new_player.invigorate()
        new_player.refresh_deck()
        
        

        if game.prnt:
            print(f"Player {old_player.team+1} ends turn and gains 2 mana.")
        old_player.employ_effects()
        new_player.record_information(game,old_player)
        if game.prnt:
            print(f"Player {old_player.team+1} has {old_player.mana} mana remaining.")
class ExecutionerMove(Move):
    def __init__(self, caster, target_square,player):
        self.caster = caster
        self.target_square = target_square
        self.mana_cost = caster.ability_cost
        self.player=player
        self.execution_threshold=caster.execution_threshold
        self.type="DamageAbility"
        self.name="Execute"
        self.movename=self.name+str(target_square.index)
    def execute(self, game):
        executionThreshhold = self.execution_threshold ######<--PERCENT health threshhold for execution to instantly kill enemy unit-->#####
        sq = self.target_square
        player=self.player
        if player.mana < self.mana_cost and not self.caster.exhausted:
            if game.prnt:
                print("❌ Not enough mana/weak targets for execution!")
                print(f" Mana needed: {self.mana_cost} Current Mana: {player.mana}")
            return
        if game.prnt:
            print(f"Player{player.team+1}'s Executioner on square {self.caster.square.index} casts Execute at enemy square {self.target_square.index}! ")
        if sq.empty or not sq.troop or not hasattr(sq.troop, "health") or sq.troop.dead:
            if game.prnt:
                print("❌ No targets for execution!")
            return
        if self.target_square.troop.health >= self.target_square.troop.initial_health * (executionThreshhold * 0.01) :
            if game.prnt:
                print("Target is not weak enough for Executioner to execute")
            return
        if game.prnt:
            print(f"Executioner executes {self.target_square.troop.name}  !!! OWNED!!!!")
        
        player.mana -= self.mana_cost
        opponent = game.players[1 - player.team]
        opponent.base_health-=2
        if game.prnt:
            print(f"Player {opponent.team+1}'s base takes 2 damage! {opponent.base_health} hp remaining!'")
        squares = opponent.available_squares
        idx = squares.index(self.target_square)
        self.caster.exhausted=True
        self.target_square.troop.die(opponent)
        self.target_square.troop = None
        self.target_square.empty = True
        if game.prnt:
            print(f"Mana left: {player.mana}")
       

        if opponent.base_health <= 0:
            if game.prnt:
                print("🎉 Opponent base destroyed! Game over.")
            game.game_over = True