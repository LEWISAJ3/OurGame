import numpy as np
from gameactions import *
from copy import deepcopy
from collections import deque  # also make sure deque is imported
alldeploys=["Wizard","ManaTower","Executioner","Ghost"]
allabilities=["Fireball","Execute","Haunt","Nuke"]
allnotarget=["HealSpell","ExorcismSpell","ThornSpell"]
allmoves=['EndTurn']
alldeploysquares=[]
allhandcards=alldeploys+allnotarget
for card in alldeploys:
    alldeploysquares.extend([card+str(x) for x in range(4)])
allmoves.extend(alldeploysquares)
for move in allabilities:
    allmoves.extend([move+str(x) for x in range(4)])
allmoves.extend([allnotarget[x] for x in range(2)])
def encodehand(hand,length=len(allhandcards)):
    small=len(allhandcards)
    return [hand.count(x) if x in hand else 0 for x in allhandcards]+[0]*max(0,length-small)
def encodemove(move,length=len(allmoves)):
    small=len(allmoves)
    return [1 if x==move else 0 for x in allmoves]+[0]*max(0,length-small)
def encodemoves(moves,length=len(allmoves)):
    small=len(allmoves)
    return [1 if x in moves else 0 for x in allmoves]+[0]*max(0,length-small)
def encodedeployed(troops,length=len(alldeploysquares)):
    small=len(alldeploysquares)
    return [1 if x in troops else 0 for x in alldeploysquares]+[0]*max(0,length-small)
def encodehealths(troops):

    return [troop.health if hasattr(troop,"health") else 0 for troop in troops]+[0]*(4-len(troops))
snapshot = {

    "My_Mana": [0],
    "Their_Mana": [0],
    "My_Health": [0],
    "Their_Health": [0],
    "Their_Card_Types_Seen":encodehand([0]),
    "Their_Currently_Visible_Cards": encodedeployed([0,0,0,0]),
    "Their_cardhealths":[0]*4,
    "Your cardhealths":[0]*4,
    "Active_Cards":encodedeployed([0,0,0,0]),
    "Deck":encodehand([]),
    "Action Taken":encodemove([])
}

information=[]
for key in snapshot.keys():
    information.extend(snapshot[key])
infolength=len(information)
import time
# -----------------------------
# Game controller
# -----------------------------
class Game:
    def __init__(self, player_1, player_2, length=10, prnt=True, offset=[0,2],show=False,record=True):
        self.turn = 0
        self.prnt = prnt
        self.moves_played = 0
        self.length = length
        self.game_over = False
        self.players = [player_1, player_2]
        
        player_1.game = self
        player_2.game = self
        player_1.inform_cards()
        player_2.inform_cards()
        player_1.team = 0
        player_2.team = 1
        player_2.base_health += offset[0]
        player_2.mana += offset[1]
        self.boards=[]
        self.show=show
        self.player_1=player_1
        self.player_2=player_2
        
        self.snaps=[]
        self.record=record
    def change_turn(self):
        self.turn = 1 - self.turn
    def rec_snap(self):
        snap = {
           
            "My_Mana": self.player_1.mana,
            "Their_Mana": self.player_2.mana,
            "My_Health": self.player_1.base_health,
            "Their_Health": self.player_2.base_health,
            
            "Their_Currently_Visible_Cards": [getattr(square.troop, "name", 0) for square in self.player_2.available_squares],
            "Their_cardhealths":[getattr(square.troop, "health", 0) for square in self.player_2.available_squares],
            "My_cardhealths":[getattr(square.troop, "health", 0) for square in self.player_1.available_squares],
            "My_Active_Cards":[getattr(square.troop, "name", 0) for square in self.player_1.available_squares],
            "Their_Deck":[getattr(card, "name", 0 )for card in self.player_2.deck],
            "My_Deck":[getattr(card, "name", 0 )for card in self.player_1.deck],
            "Action Taken":[""]
            
        }
        
        self.snaps.append(snap)
        

    def play(self):
        start=time.time()
        while self.moves_played < self.length and not self.game_over:
            player = self.players[self.turn]
            opponent = self.players[self.turn-1]
            if self.prnt:
                print(f"\n--- Turn {self.moves_played}, Player {self.turn+1} ---")
            self.rec_snap()
            player.make_move(self)
            
            if self.show:
                self.show_board()
            if time.time()-start>20:
                return self.end_game()
            
        return self.end_game()

    def end_game(self):
        p1, p2 = self.players
        if p1.base_health > p2.base_health:
            return 1
        elif p1.base_health < p2.base_health:
            return -1
        return 0
    def show_board(self):
        print("----------------------------------------------")
        print("Current Board:")
        print(f"Player 2 Health:{self.player_2.base_health}")
        print(f"Player 2 Mana:{self.player_2.mana}")
        print("Player 2 cards in hand:")
        print(*[card.name for card in self.player_2.deck])
        print("Player 2 troops deployed:")
        print(*[square.troop.name if not square.empty else "____" for square in self.player_2.available_squares])
        print("Player 1 troops deployed:")
        print(*[square.troop.name if not square.empty else "____" for square in self.player_1.available_squares])
        print("Player 1 cards in hand:")
        print(*[card.name for card in self.player_1.deck])
        print(f"Player 1 Health:{self.player_1.base_health}")
        print(f"Player 1 Mana:{self.player_1.mana}")
        print("----------------------------------------------")
from collections import deque
# -----------------------------
# GamePlayer
# -----------------------------
class GamePlayer:
    def __init__(self, difficulty, game, deck, decision_maker,length=len(allmoves)):
        self.difficulty = difficulty
        self.game = game
        # Start with the full deck as "largedeck"
        self.largedeck = deque(deepcopy(deck))
        
        self.deck = []  # current hand (max 5)
        self.active_cards = []
        self.decision_maker = decision_maker
        self.team = None
        self.available_squares = [Square(i) for i in range(4)]
        self.mana = 30
        self.base_health = 15
        # draw initial hand
        self.draw_cards()
        self.move="EndTurn"
        snapshot = {
           
            "My_Mana": [self.mana],
            "Their_Mana": [self.mana],
            "My_Health": [self.base_health],
            "Their_Health": [self.base_health],
            "Their_Card_Types_Seen":encodehand([0]),
            "Their_Currently_Visible_Cards": encodedeployed([0,0,0,0]),
            "Their_cardhealths":[0]*4,
            "Your cardhealths":[0]*4,
            "Active_Cards":encodedeployed([0,0,0,0]),
            "Deck":encodehand(self.deck),
            "Action Taken":encodemove(self.move)
        }
        self.information=[]
        for key in snapshot.keys():
            self.information.extend(snapshot[key])
        self.known_enemy_types = set()
        self.passive_effectors=[]
    def inform_cards(self):
        for card in self.largedeck:
            card.gain_player(self)
        for card in self.deck:
            card.gain_player(self)
        for card in self.active_cards:
            card.gain_player(self)
    def clone(self):
        return deepcopy(self)

    def draw_cards(self):
        """Refill hand up to 5 cards from largedeck."""
        while len(self.deck) < 5 and self.largedeck:
            
            self.deck.append(self.largedeck.pop())

    def refresh_deck(self):
        """Call this at the start of a turn to ensure 5 cards in hand."""
        self.draw_cards()

    def get_possible_moves(self, game):
        moves = [EndTurnMove(self)]
        # Only consider cards that are alive
        extend_deck = [c for c in self.deck + self.active_cards]

        for card in extend_deck:
            moves.extend(card.get_possible_moves(game,self))

        return moves

    def make_move(self, game):
        self.inform_cards()
        moves = self.get_possible_moves(game)
        if moves:
            move = self.decision_maker.choose_move(moves,self.information)
            self.move=move.movename
            move.execute(game)
    

    def record_information(self, game,opponent,length=len(allmoves)):
        
        visible_enemy_cards = [c for c in opponent.active_cards if not getattr(c, "hidden", False)]

        # update memory of seen types
        self.known_enemy_types.update(c.name+str(c.square.index) for c in visible_enemy_cards)
        
        enemy_list=list(self.known_enemy_types) +[0]*(length-len(self.known_enemy_types))
        
        snapshot = {
           
            "My_Mana": [int(self.mana)],
            "Their_Mana": [int(opponent.mana)],
            "My_Health": [int(self.base_health)],
            "Their_Health": [int(opponent.base_health)],
            "Their_Card_Types_Seen":encodehand(enemy_list) ,
            "Their_Currently_Visible_Cards": encodedeployed([square.troop.name+str(square.index) if not square.empty else 0 for square in opponent.available_squares]),
            "Their_cardhealths":encodehealths(opponent.active_cards),
            "Your cardhealths":encodehealths(self.active_cards),
            "Active_Cards":encodedeployed([square.troop.name+str(square.index) if not square.empty else 0 for square in self.available_squares]),
            "Deck":encodehand([c.name for c in self.deck]),
            "Action Taken":encodemove(self.move)
            
        }
      
        self.information=[]
        for key in snapshot.keys():
            self.information.extend(snapshot[key])
    def invigorate(self):
        for card in self.active_cards:
            card.exhausted=False
    def employ_effects(self):
        for effect in self.passive_effectors:
            effect.tick(self)
